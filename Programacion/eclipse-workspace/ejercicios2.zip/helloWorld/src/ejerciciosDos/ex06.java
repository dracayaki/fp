package ejerciciosDos;

public class ex06 {

		public static void main(String[] args) {
		
			int tirada1, tirada2, tirada3, sumaTotal;
			
			System.out.println("A continuación te mostrare tres tiradas de un dado, y la suma total de ellas");
	
			tirada1 	= (int)(Math.random() * 6) + 1;
			tirada2		= (int)(Math.random() * 6) + 1;
			tirada3		= (int)(Math.random() * 6) + 1;

			sumaTotal	= tirada1 + tirada2 + tirada3;
			
			System.out.println("El resultado de la primer tirada es: " + tirada1);
			System.out.println("El resultado de la segunda tirada es: " + tirada2);
			System.out.println("El resultado de la tercera tirada es: " + tirada3);
			System.out.println("La suma total de las tres tiradas es:" + sumaTotal);
		}
}
