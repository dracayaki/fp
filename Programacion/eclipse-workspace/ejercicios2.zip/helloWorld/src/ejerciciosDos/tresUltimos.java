package ejerciciosDos;

import java.util.Scanner;

public class tresUltimos {

	public static void main(String[] args) {
		
		String	cadena, cadena2;
		int		longitud;
		
		System.out.println("Dime una cadena de caracteres");
		Scanner sc 	= new Scanner(System.in);
		
		cadena		= sc.nextLine();
		longitud	= cadena.length();
		cadena2		= cadena.substring(longitud-3, longitud);
		
		System.out.println(cadena2);
		
		sc.close();
		
	}
	
}
