package ejerciciosDos;

import java.util.Scanner;

public class imprimirDos {
	public static void main(String[] args) {
		
		String cadena;
		String cadena2;
		
		System.out.println("Dime una cadena de caracteres");
		Scanner sc	= new Scanner(System.in);
		
		cadena		= sc.nextLine();
		cadena2 	= cadena.substring(0,2);
		
		System.out.println(cadena2);
		
		sc.close();
		
		}
}
