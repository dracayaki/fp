package ejerciciosDos;

import java.util.Scanner;

public class ex05 {

	public static void main(String[] args) {
		
		String cadena;
		
		System.out.println("Dime una cadena de caracteres, y te mostraré todo en mayusculas");
		Scanner sc	= new Scanner(System.in);
		cadena		= sc.nextLine();
		
		cadena		= cadena.toUpperCase();
		
		System.out.println(cadena);
		
		sc.close();
	}
	
}
